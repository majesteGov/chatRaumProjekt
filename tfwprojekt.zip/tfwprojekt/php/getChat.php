<?php
include("dbconnection.php");
session_start();
$outgoingid = $_SESSION['id'];
$incomingid = mysqli_real_escape_string($conn, $_POST['incomingid']);

$getMsgQuery = "SELECT * FROM `messages` LEFT JOIN `users` ON messages.outgoing = users.id
WHERE outgoing = '{$outgoingid}' AND incoming = '{$incomingid}' OR outgoing = '{$incomingid}' AND incoming = '{$outgoingid}'";
$runGetMsgQuery = mysqli_query($conn, $getMsgQuery);
if(!$runGetMsgQuery){
    echo "Query Failed";
}else{
    if(mysqli_num_rows($runGetMsgQuery) > 0){
        while($row = mysqli_fetch_assoc($runGetMsgQuery)){
            if($row['outgoing'] == $outgoingid){
                echo '<div class="responseCard outgoing">
                <div class="response">
                    <h3 class="name">'.$row["firstName"]." ".$row["lastName"].'</h3>
                    <p class="messages">'.$row["messages"].'</p>
                </div>
            </div>';
            }else{
                echo '<div class="request incoming">
                <h3 class="name">'.$row["firstName"]." ".$row["lastName"].'</h3>
                <p class="messages">'.$row["messages"].'</p>
            </div>';
            }
        }
    }else{
        echo '<div id="errors">Es sind keine Nachrichten vorhanden</div>';
    }
}
?>