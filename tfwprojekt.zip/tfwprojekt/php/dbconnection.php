<?php
$conn = mysqli_connect("localhost","root","","tfwdb");
if(!$conn){
    echo "Connection Failed";
}
?>