<?php
include("dbconnection.php");

while($row = mysqli_fetch_assoc($query)){
$outgoing = $_SESSION['id'];
$incoming = $row['id'];
$sql = "SELECT * FROM `messages` WHERE (incoming = '{$incoming}' 
AND outgoing = '{$outgoing}') OR (incoming = '{$outgoing}' AND outgoing = '{$incoming}') 
ORDER BY messages_id DESC LIMIT 1";

$runSQL = mysqli_query($conn, $sql);

if($runSQL){
    $row2 = mysqli_fetch_assoc($runSQL);
    if(mysqli_num_rows($runSQL) > 0){
        $lastMessage = $row2['messages'];
    }else{
        $lastMessage = "keine Nachricht verfügbar";
    }
}else{
    echo "Query Failed";
}
if($row['status'] == "Online"){
    $status = "online";
}else{
    $status = "offline";
}
    $onlineUsers = '<a href="messages.php?userid='.$row["id"].'">
    <div class="profile">
        <div class="image">
            <img src="images/'.$row["image"].'" alt="">
        </div>
        <h2 class="name">'.$row["firstName"]." ".$row["lastName"].'</h2>
        <p class="lastMessage">'.$lastMessage.'</p>
        <div class="status '.$status.'"></div>
    </div>
</a>';
echo $onlineUsers;
};
